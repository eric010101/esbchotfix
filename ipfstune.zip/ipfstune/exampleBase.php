<?php
require('../phpweb3/vendor/autoload.php');
use Web3\Web3;
$web3 = new Web3('http://localhost:8546/');

